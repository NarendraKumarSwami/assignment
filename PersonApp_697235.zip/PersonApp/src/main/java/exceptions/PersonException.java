package exceptions;

public class PersonException extends Exception {

}

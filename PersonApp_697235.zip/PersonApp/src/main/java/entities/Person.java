package entities;

public class Person {

}

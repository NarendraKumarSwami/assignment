package exceptions;

public class EmployeeAddressException extends Exception {

}

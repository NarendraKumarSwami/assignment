package exceptions;

public class EmployeeException extends Exception {

}

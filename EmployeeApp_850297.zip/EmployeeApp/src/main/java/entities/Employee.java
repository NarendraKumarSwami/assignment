package entities;

public class Employee {

}
